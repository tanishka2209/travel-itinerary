import logo from './logo.svg';
import './App.css';
import TravelItineraryGenerator from './TravelItineraryGenerator';

function App() {
  return (
    <div className="App">
      <TravelItineraryGenerator />
    </div>
  );
}

export default App;
